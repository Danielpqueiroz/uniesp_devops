package br.com.apidaniel.danielpontes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DanielpontesApplication {

	public static void main(String[] args) {
		SpringApplication.run(DanielpontesApplication.class, args);
	}

}
